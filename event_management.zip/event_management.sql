-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 06, 2025 at 08:16 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `event_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `event_id` int(11) NOT NULL,
  `creator_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `location` varchar(255) NOT NULL,
  `event_date` date NOT NULL,
  `event_time` time NOT NULL,
  `contact_info` varchar(100) DEFAULT NULL,
  `max_participants` int(11) DEFAULT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`event_id`, `creator_id`, `title`, `description`, `location`, `event_date`, `event_time`, `contact_info`, `max_participants`, `creation_date`) VALUES
(1, 1, 'Invitacion prueba', 'Puede asistir todo el mundo, es una prueba!', 'Servidor prueba', '2025-06-12', '18:30:00', '304587940', 30, '2025-04-06 04:51:44'),
(2, 1, 'otra prueba', 'bienvenidos!', 'mi casa', '2025-05-12', '12:50:00', '30000000000', 10, '2025-04-06 04:55:37'),
(3, 1, 'maximo 1', 'hola! maximo 1', 'maximooo', '2055-10-30', '12:00:00', '3000000000', 1, '2025-04-06 04:56:18'),
(4, 2, 'maximo 1', 'maximo 1, no lo olvides', 'hola2', '2025-05-30', '12:22:00', '30425242542', 1, '2025-04-06 05:17:55');

-- --------------------------------------------------------

--
-- Table structure for table `invitations`
--

CREATE TABLE `invitations` (
  `invitation_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `invitation_code` varchar(50) NOT NULL,
  `status` enum('PENDING','ACCEPTED','DECLINED') DEFAULT 'PENDING',
  `sent_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `response_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invitations`
--

INSERT INTO `invitations` (`invitation_id`, `event_id`, `email`, `invitation_code`, `status`, `sent_date`, `response_date`) VALUES
(1, 1, 'loca@gmail.com', '7be9ceda-5757-4625-9746-02312bed4c6a', 'PENDING', '2025-04-06 04:52:29', NULL),
(2, 1, 'genial@gmail.com', '0d44105f-39ce-47ae-822e-21572ac81204', 'PENDING', '2025-04-06 04:52:37', NULL),
(3, 1, 'prueba@gmail.com', '0771956c-2184-4e05-b5ad-e602a1d2fcd4', 'PENDING', '2025-04-06 04:52:43', NULL),
(4, 1, 'link@gmail.com', '2dd01402-46ec-46c9-ae45-9220c7e1f43a', 'PENDING', '2025-04-06 04:53:05', NULL),
(5, 3, 'maximo1@gmail.com', '2e9c1892-d7b3-4e89-abb8-5abb12c2c822', 'ACCEPTED', '2025-04-06 04:56:29', '2025-04-06 04:57:40'),
(6, 3, 'hola@gmail.com', '8e8df732-6958-47d4-b4a8-c4d74e26dbdd', 'ACCEPTED', '2025-04-06 04:56:37', '2025-04-06 04:57:58'),
(9, 4, 'prueba2@gmail.com', 'b651f853-0d9c-43f7-9ab6-65bfbf9089dc', 'ACCEPTED', '2025-04-06 05:20:15', '2025-04-06 05:20:29');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `registration_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `email`, `full_name`, `registration_date`) VALUES
(1, 'jola', 'llamas', 'lama@gmail.com', 'jamas', '2025-04-06 04:50:06'),
(2, 'juan', 'llamas', 'llamas1@gmail.com', 'llamas cardenas', '2025-04-06 05:16:34'),
(3, 'Prueba 2', 'prueba', 'prueba2@gmail.com', 'solo es una prueba dos', '2025-04-06 05:19:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`),
  ADD KEY `creator_id` (`creator_id`);

--
-- Indexes for table `invitations`
--
ALTER TABLE `invitations`
  ADD PRIMARY KEY (`invitation_id`),
  ADD UNIQUE KEY `invitation_code` (`invitation_code`),
  ADD KEY `event_id` (`event_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `invitations`
--
ALTER TABLE `invitations`
  MODIFY `invitation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_ibfk_1` FOREIGN KEY (`creator_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `invitations`
--
ALTER TABLE `invitations`
  ADD CONSTRAINT `invitations_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
