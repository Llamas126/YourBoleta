package model;
// AUTOR: JUAN CAMILO LLAMAS  | FECHA: 2025-3-04

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import database.DatabaseConnection;

public class Invitation {
    public enum Status {
        PENDING, ACCEPTED, DECLINED
    }

    private int invitationId;
    private int eventId;
    private String email;
    private String invitationCode;
    private Status status;
    private Timestamp sentDate;
    private Timestamp responseDate;

    // Constructor for new invitation
    public Invitation(int eventId, String email) {
        this.eventId = eventId;
        this.email = email;
        this.invitationCode = UUID.randomUUID().toString();
        this.status = Status.PENDING;
    }

    // Constructor for existing invitation
    public Invitation(int invitationId, int eventId, String email, String invitationCode,
                      Status status, Timestamp sentDate, Timestamp responseDate) {
        this.invitationId = invitationId;
        this.eventId = eventId;
        this.email = email;
        this.invitationCode = invitationCode;
        this.status = status;
        this.sentDate = sentDate;
        this.responseDate = responseDate;
    }

    // Getters and setters
    public int getInvitationId() {
        return invitationId;
    }

    public void setInvitationId(int invitationId) {
        this.invitationId = invitationId;
    }

    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getInvitationCode() {
        return invitationCode;
    }

    public void setInvitationCode(String invitationCode) {
        this.invitationCode = invitationCode;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public Timestamp getSentDate() {
        return sentDate;
    }

    public void setSentDate(Timestamp sentDate) {
        this.sentDate = sentDate;
    }

    public Timestamp getResponseDate() {
        return responseDate;
    }

    public void setResponseDate(Timestamp responseDate) {
        this.responseDate = responseDate;
    }

    // Database operations
    public boolean save() {
        String sql = "INSERT INTO invitations (event_id, email, invitation_code, status) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setInt(1, eventId);
            pstmt.setString(2, email);
            pstmt.setString(3, invitationCode);
            pstmt.setString(4, status.name());

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        this.invitationId = generatedKeys.getInt(1);
                        return true;
                    }
                }
            }
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateStatus(Status newStatus) {
        // Verificar si ya se alcanzó el máximo de asistentes
        if (newStatus == Status.ACCEPTED) {
            Event event = Event.getEventById(eventId);
            if (event != null) {
                int confirmedAttendees = getConfirmedAttendeesCount(eventId);
                if (confirmedAttendees >= event.getMaxParticipants()) {
                    return false; // No se puede aceptar más invitaciones
                }
            }
        }

        String sql = "UPDATE invitations SET status = ?, response_date = CURRENT_TIMESTAMP WHERE invitation_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, newStatus.name());
            pstmt.setInt(2, invitationId);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean delete() {
        String sql = "DELETE FROM invitations WHERE invitation_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, invitationId);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean update() {
        String sql = "UPDATE invitations SET email = ?, status = ? WHERE invitation_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, email);
            pstmt.setString(2, status.name());
            pstmt.setInt(3, invitationId);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<Invitation> getInvitationsByEvent(int eventId) {
        List<Invitation> invitations = new ArrayList<>();
        String sql = "SELECT * FROM invitations WHERE event_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, eventId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    invitations.add(new Invitation(
                            rs.getInt("invitation_id"),
                            rs.getInt("event_id"),
                            rs.getString("email"),
                            rs.getString("invitation_code"),
                            Status.valueOf(rs.getString("status")),
                            rs.getTimestamp("sent_date"),
                            rs.getTimestamp("response_date")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return invitations;
    }

    public static Invitation getInvitationByCode(String code) {
        String sql = "SELECT * FROM invitations WHERE invitation_code = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, code);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Invitation(
                            rs.getInt("invitation_id"),
                            rs.getInt("event_id"),
                            rs.getString("email"),
                            rs.getString("invitation_code"),
                            Status.valueOf(rs.getString("status")),
                            rs.getTimestamp("sent_date"),
                            rs.getTimestamp("response_date")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static int getConfirmedAttendeesCount(int eventId) {
        String sql = "SELECT COUNT(*) FROM invitations WHERE event_id = ? AND status = 'ACCEPTED'";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, eventId);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public static List<Invitation> getInvitationsByEmail(String email) {
        List<Invitation> invitations = new ArrayList<>();
        String sql = "SELECT i.*, e.title as event_title FROM invitations i " +
                "JOIN events e ON i.event_id = e.event_id " +
                "WHERE i.email = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, email);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Invitation invitation = new Invitation(
                            rs.getInt("invitation_id"),
                            rs.getInt("event_id"),
                            rs.getString("email"),
                            rs.getString("invitation_code"),
                            Status.valueOf(rs.getString("status")),
                            rs.getTimestamp("sent_date"),
                            rs.getTimestamp("response_date")
                    );
                    invitations.add(invitation);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return invitations;
    }
}

