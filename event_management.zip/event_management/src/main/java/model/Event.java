package model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import database.DatabaseConnection;
// AUTOR: JUAN CAMILO LLAMAS  | FECHA: 2025-3-04

public class Event {
    private int eventId;
    private int creatorId;
    private String title;
    private String description;
    private String location;
    private Date eventDate;
    private Time eventTime;
    private String contactInfo;
    private int maxParticipants;
    private java.util.Date creationDate;

    // Constructor for new event
    public Event(int creatorId, String title, String description, String location,
                 Date eventDate, Time eventTime, String contactInfo, int maxParticipants) {
        this.creatorId = creatorId;
        this.title = title;
        this.description = description;
        this.location = location;
        this.eventDate = eventDate;
        this.eventTime = eventTime;
        this.contactInfo = contactInfo;
        this.maxParticipants = maxParticipants;
    }

    // Constructor for existing event
    public Event(int eventId, int creatorId, String title, String description, String location,
                 Date eventDate, Time eventTime, String contactInfo, int maxParticipants,
                 java.util.Date creationDate) {
        this.eventId = eventId;
        this.creatorId = creatorId;
        this.title = title;
        this.description = description;
        this.location = location;
        this.eventDate = eventDate;
        this.eventTime = eventTime;
        this.contactInfo = contactInfo;
        this.maxParticipants = maxParticipants;
        this.creationDate = creationDate;
    }

    // Getters and setters
    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public int getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(int creatorId) {
        this.creatorId = creatorId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Date getEventDate() {
        return eventDate;
    }

    public void setEventDate(Date eventDate) {
        this.eventDate = eventDate;
    }

    public Time getEventTime() {
        return eventTime;
    }

    public void setEventTime(Time eventTime) {
        this.eventTime = eventTime;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }

    public int getMaxParticipants() {
        return maxParticipants;
    }

    public void setMaxParticipants(int maxParticipants) {
        this.maxParticipants = maxParticipants;
    }

    public java.util.Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(java.util.Date creationDate) {
        this.creationDate = creationDate;
    }

    // Database operations
    public boolean save() {
        String sql = "INSERT INTO events (creator_id, title, description, location, event_date, " +
                "event_time, contact_info, max_participants) VALUES (?,   event_date, " +
                "event_time, contact_info, max_participants) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setInt(1, creatorId);
            pstmt.setString(2, title);
            pstmt.setString(3, description);
            pstmt.setString(4, location);
            pstmt.setDate(5, eventDate);
            pstmt.setTime(6, eventTime);
            pstmt.setString(7, contactInfo);
            pstmt.setInt(8, maxParticipants);

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        this.eventId = generatedKeys.getInt(1);
                        return true;
                    }
                }
            }
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean update() {
        String sql = "UPDATE events SET title = ?, description = ?, location = ?, event_date = ?, " +
                "event_time = ?, contact_info = ?, max_participants = ? WHERE event_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, title);
            pstmt.setString(2, description);
            pstmt.setString(3, location);
            pstmt.setDate(4, eventDate);
            pstmt.setTime(5, eventTime);
            pstmt.setString(6, contactInfo);
            pstmt.setInt(7, maxParticipants);
            pstmt.setInt(8, eventId);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<Event> getEventsByCreator(int creatorId) {
        List<Event> events = new ArrayList<>();
        String sql = "SELECT * FROM events WHERE creator_id = ? ORDER BY event_date, event_time";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, creatorId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    events.add(new Event(
                            rs.getInt("event_id"),
                            rs.getInt("creator_id"),
                            rs.getString("title"),
                            rs.getString("description"),
                            rs.getString("location"),
                            rs.getDate("event_date"),
                            rs.getTime("event_time"),
                            rs.getString("contact_info"),
                            rs.getInt("max_participants"),
                            rs.getTimestamp("creation_date")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return events;
    }

    public static Event getEventById(int eventId) {
        String sql = "SELECT * FROM events WHERE event_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, eventId);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Event(
                            rs.getInt("event_id"),
                            rs.getInt("creator_id"),
                            rs.getString("title"),
                            rs.getString("description"),
                            rs.getString("location"),
                            rs.getDate("event_date"),
                            rs.getTime("event_time"),
                            rs.getString("contact_info"),
                            rs.getInt("max_participants"),
                            rs.getTimestamp("creation_date")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}

