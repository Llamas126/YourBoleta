package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.Event;
import model.Invitation;
// AUTOR: JUAN CAMILO LLAMAS  | FECHA: 2025-3-04

public class InvitationResponseFrame extends JFrame {
    private JTextField codeField;
    private JButton checkButton;
    private JPanel responsePanel;

    public InvitationResponseFrame() {
        setTitle("Responder a Invitación");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Título
        JLabel titleLabel = new JLabel("Responder a Invitación de Evento", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        // Entrada de código
        JPanel codePanel = new JPanel();
        codePanel.setLayout(new BorderLayout(5, 0));
        codePanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        JLabel codeLabel = new JLabel("Ingrese Código de Invitación: ");
        codeField = new JTextField();
        checkButton = new JButton("Verificar");

        codePanel.add(codeLabel, BorderLayout.WEST);
        codePanel.add(codeField, BorderLayout.CENTER);
        codePanel.add(checkButton, BorderLayout.EAST);

        mainPanel.add(codePanel, BorderLayout.CENTER);

        // Panel de respuesta (inicialmente vacío)
        responsePanel = new JPanel();
        responsePanel.setLayout(new BorderLayout());
        responsePanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        mainPanel.add(responsePanel, BorderLayout.SOUTH);

        // Agregar action listeners
        checkButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkInvitation();
            }
        });

        add(mainPanel);
    }

    private void checkInvitation() {
        String code = codeField.getText().trim();

        if (code.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor ingrese un código de invitación",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Invitation invitation = Invitation.getInvitationByCode(code);

        if (invitation == null) {
            JOptionPane.showMessageDialog(this, "Código de invitación inválido",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (invitation.getStatus() != Invitation.Status.PENDING) {
            JOptionPane.showMessageDialog(this, "Ya ha respondido a esta invitación",
                    "Información", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        Event event = Event.getEventById(invitation.getEventId());

        if (event == null) {
            JOptionPane.showMessageDialog(this, "Evento no encontrado",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        displayEventDetails(event, invitation);
    }

    private void displayEventDetails(Event event, Invitation invitation) {
        responsePanel.removeAll();

        JPanel eventPanel = new JPanel();
        eventPanel.setLayout(new GridLayout(4, 1, 5, 5));
        eventPanel.setBorder(BorderFactory.createTitledBorder("Detalles del Evento"));

        JLabel titleLabel = new JLabel("Evento: " + event.getTitle());
        JLabel dateLabel = new JLabel("Fecha: " + event.getEventDate() + " a las " + event.getEventTime());
        JLabel locationLabel = new JLabel("Ubicación: " + event.getLocation());
        JLabel contactLabel = new JLabel("Contacto: " + event.getContactInfo());

        eventPanel.add(titleLabel);
        eventPanel.add(dateLabel);
        eventPanel.add(locationLabel);
        eventPanel.add(contactLabel);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));

        JButton acceptButton = new JButton("Aceptar");
        JButton declineButton = new JButton("Rechazar");

        acceptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                respondToInvitation(invitation, Invitation.Status.ACCEPTED);
            }
        });

        declineButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                respondToInvitation(invitation, Invitation.Status.DECLINED);
            }
        });

        buttonPanel.add(acceptButton);
        buttonPanel.add(declineButton);

        responsePanel.add(eventPanel, BorderLayout.CENTER);
        responsePanel.add(buttonPanel, BorderLayout.SOUTH);

        responsePanel.revalidate();
        responsePanel.repaint();

        // Redimensionar ventana para ajustar contenido
        pack();
        setSize(getWidth(), getHeight() + 200);
    }

    private void respondToInvitation(Invitation invitation, Invitation.Status status) {
        // Verificar si ya se alcanzó el máximo de asistentes confirmados
        if (status == Invitation.Status.ACCEPTED) {
            Event event = Event.getEventById(invitation.getEventId());
            int confirmedAttendees = Invitation.getConfirmedAttendeesCount(event.getEventId());

            if (confirmedAttendees >= event.getMaxParticipants()) {
                JOptionPane.showMessageDialog(this,
                        "Lo sentimos, este evento ha alcanzado su capacidad máxima de " + event.getMaxParticipants() + " asistentes.",
                        "Capacidad Máxima Alcanzada", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        if (invitation.updateStatus(status)) {
            String message = status == Invitation.Status.ACCEPTED ?
                    "¡Ha aceptado la invitación!" :
                    "Ha rechazado la invitación.";

            JOptionPane.showMessageDialog(this, message,
                    "Respuesta Registrada", JOptionPane.INFORMATION_MESSAGE);

            // Limpiar panel de respuesta
            responsePanel.removeAll();
            responsePanel.revalidate();
            responsePanel.repaint();

            // Restablecer tamaño
            setSize(500, 400);

            // Limpiar campo de código
            codeField.setText("");
        } else {
            if (status == Invitation.Status.ACCEPTED) {
                JOptionPane.showMessageDialog(this,
                        "Lo sentimos, este evento ha alcanzado su capacidad máxima. Su respuesta no pudo ser registrada.",
                        "Capacidad Máxima Alcanzada", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Error al registrar su respuesta. Por favor intente nuevamente.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}

