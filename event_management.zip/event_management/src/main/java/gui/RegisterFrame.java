package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.User;
// AUTOR: JUAN CAMILO LLAMAS  | FECHA: 2025-3-04

public class RegisterFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JTextField emailField;
    private JTextField fullNameField;
    private JButton registerButton;
    private JButton backButton;
    private JFrame parentFrame;

    public RegisterFrame(JFrame parentFrame) {
        this.parentFrame = parentFrame;

        setTitle("Sistema de Gestión de Eventos - Registro");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Título
        JLabel titleLabel = new JLabel("Crear Nueva Cuenta", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        // Formulario de registro
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(5, 2, 10, 10));

        JLabel usernameLabel = new JLabel("Nombre de usuario:");
        usernameField = new JTextField();
        JLabel passwordLabel = new JLabel("Contraseña:");
        passwordField = new JPasswordField();
        JLabel confirmPasswordLabel = new JLabel("Confirmar Contraseña:");
        confirmPasswordField = new JPasswordField();
        JLabel emailLabel = new JLabel("Correo electrónico:");
        emailField = new JTextField();
        JLabel fullNameLabel = new JLabel("Nombre completo:");
        fullNameField = new JTextField();

        formPanel.add(usernameLabel);
        formPanel.add(usernameField);
        formPanel.add(passwordLabel);
        formPanel.add(passwordField);
        formPanel.add(confirmPasswordLabel);
        formPanel.add(confirmPasswordField);
        formPanel.add(emailLabel);
        formPanel.add(emailField);
        formPanel.add(fullNameLabel);
        formPanel.add(fullNameField);

        mainPanel.add(formPanel, BorderLayout.CENTER);

        // Botones
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 0));

        registerButton = new JButton("Registrarse");
        backButton = new JButton("Volver al Inicio de Sesión");

        buttonPanel.add(registerButton);
        buttonPanel.add(backButton);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Agregar action listeners
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                register();
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goBackToLogin();
            }
        });

        add(mainPanel);
    }

    private void register() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        String email = emailField.getText();
        String fullName = fullNameField.getText();

        // Validar entrada
        if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() ||
                email.isEmpty() || fullName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios", "Error de Registro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this, "Las contraseñas no coinciden", "Error de Registro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            JOptionPane.showMessageDialog(this, "Formato de correo electrónico inválido", "Error de Registro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verificar si el nombre de usuario o correo ya existen
        if (!User.isUsernameAvailable(username)) {
            JOptionPane.showMessageDialog(this, "El nombre de usuario ya existe", "Error de Registro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!User.isEmailAvailable(email)) {
            JOptionPane.showMessageDialog(this, "El correo electrónico ya existe", "Error de Registro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Crear y guardar usuario
        User user = new User(username, password, email, fullName);
        if (user.save()) {
            JOptionPane.showMessageDialog(this, "¡Registro exitoso! Ahora puede iniciar sesión.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            goBackToLogin();
        } else {
            JOptionPane.showMessageDialog(this, "Error en el registro. Por favor intente nuevamente.", "Error de Registro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void goBackToLogin() {
        parentFrame.setVisible(true);
        this.dispose();
    }
}

