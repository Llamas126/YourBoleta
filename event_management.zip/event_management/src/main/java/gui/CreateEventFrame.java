package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import model.Event;
import model.User;
// AUTOR: JUAN CAMILO LLAMAS  | FECHA: 2025-3-04

public class CreateEventFrame extends JFrame {
    private User currentUser;
    private DashboardFrame parentFrame;

    private JTextField titleField;
    private JTextArea descriptionArea;
    private JTextField locationField;
    private JTextField dateField;
    private JTextField timeField;
    private JTextField contactField;
    private JTextField maxParticipantsField;
    private JButton createButton;
    private JButton cancelButton;

    public CreateEventFrame(User user, DashboardFrame parentFrame) {
        this.currentUser = user;
        this.parentFrame = parentFrame;

        setTitle("Crear Nuevo Evento");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Título
        JLabel titleLabel = new JLabel("Crear Nuevo Evento", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        // Formulario
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(7, 2, 10, 10));

        formPanel.add(new JLabel("Título:"));
        titleField = new JTextField();
        formPanel.add(titleField);

        formPanel.add(new JLabel("Ubicación:"));
        locationField = new JTextField();
        formPanel.add(locationField);

        formPanel.add(new JLabel("Fecha (AAAA-MM-DD):"));
        dateField = new JTextField();
        formPanel.add(dateField);

        formPanel.add(new JLabel("Hora (HH:MM):"));
        timeField = new JTextField();
        formPanel.add(timeField);

        formPanel.add(new JLabel("Información de Contacto:"));
        contactField = new JTextField();
        formPanel.add(contactField);

        formPanel.add(new JLabel("Máximo de Participantes:"));
        maxParticipantsField = new JTextField();
        formPanel.add(maxParticipantsField);

        formPanel.add(new JLabel("Descripción:"));
        descriptionArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(descriptionArea);
        formPanel.add(scrollPane);

        mainPanel.add(formPanel, BorderLayout.CENTER);

        // Botones
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 0));

        createButton = new JButton("Crear Evento");
        cancelButton = new JButton("Cancelar");

        buttonPanel.add(createButton);
        buttonPanel.add(cancelButton);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Agregar action listeners
        createButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createEvent();
            }
        });

        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        add(mainPanel);
    }

    private void createEvent() {
        // Validar entrada
        String title = titleField.getText();
        String description = descriptionArea.getText();
        String location = locationField.getText();
        String dateStr = dateField.getText();
        String timeStr = timeField.getText();
        String contact = contactField.getText();
        String maxParticipantsStr = maxParticipantsField.getText();

        if (title.isEmpty() || location.isEmpty() || dateStr.isEmpty() ||
                timeStr.isEmpty() || maxParticipantsStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos excepto descripción son obligatorios",
                    "Error de Validación", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Analizar fecha y hora
        Date eventDate;
        Time eventTime;
        int maxParticipants;

        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date parsedDate = dateFormat.parse(dateStr);
            eventDate = new Date(parsedDate.getTime());
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(this, "Formato de fecha inválido. Use AAAA-MM-DD",
                    "Error de Validación", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
            java.util.Date parsedTime = timeFormat.parse(timeStr);
            eventTime = new Time(parsedTime.getTime());
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(this, "Formato de hora inválido. Use HH:MM",
                    "Error de Validación", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            maxParticipants = Integer.parseInt(maxParticipantsStr);
            if (maxParticipants <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El máximo de participantes debe ser un número positivo",
                    "Error de Validación", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Crear y guardar evento
        Event event = new Event(
                currentUser.getUserId(),
                title,
                description,
                location,
                eventDate,
                eventTime,
                contact,
                maxParticipants
        );

        if (event.save()) {
            JOptionPane.showMessageDialog(this, "¡Evento creado exitosamente!",
                    "Éxito", JOptionPane.INFORMATION_MESSAGE);
            parentFrame.refreshEvents();
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Error al crear el evento. Por favor intente nuevamente.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

