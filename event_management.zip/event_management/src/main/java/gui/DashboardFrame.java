package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import model.Event;
import model.Invitation;
import model.User;
// AUTOR: JUAN CAMILO LLAMAS  | FECHA: 2025-3-04

public class DashboardFrame extends JFrame {
    private User currentUser;
    private JButton createEventButton;
    private JButton viewInvitationsButton;
    private JButton myInvitationsButton;
    private JButton logoutButton;
    private JPanel eventsPanel;

    public DashboardFrame(User user) {
        this.currentUser = user;

        setTitle("Sistema de Gestión de Eventos - Panel Principal");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Encabezado
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BorderLayout());

        JLabel welcomeLabel = new JLabel("Bienvenido, " + user.getFullName() + "!");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        headerPanel.add(welcomeLabel, BorderLayout.WEST);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        createEventButton = new JButton("Crear Evento");
        viewInvitationsButton = new JButton("Ver Invitaciones");
        myInvitationsButton = new JButton("Mis Invitaciones");
        logoutButton = new JButton("Cerrar Sesión");

        buttonPanel.add(createEventButton);
        buttonPanel.add(viewInvitationsButton);
        buttonPanel.add(myInvitationsButton);
        buttonPanel.add(logoutButton);

        headerPanel.add(buttonPanel, BorderLayout.EAST);

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Lista de eventos
        JLabel eventsLabel = new JLabel("Tus Eventos");
        eventsLabel.setFont(new Font("Arial", Font.BOLD, 16));

        eventsPanel = new JPanel();
        eventsPanel.setLayout(new BoxLayout(eventsPanel, BoxLayout.Y_AXIS));

        JScrollPane scrollPane = new JScrollPane(eventsPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());

        JPanel eventsContainer = new JPanel();
        eventsContainer.setLayout(new BorderLayout());
        eventsContainer.add(eventsLabel, BorderLayout.NORTH);
        eventsContainer.add(scrollPane, BorderLayout.CENTER);

        mainPanel.add(eventsContainer, BorderLayout.CENTER);

        // Agregar action listeners
        createEventButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openCreateEventFrame();
            }
        });

        viewInvitationsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openInvitationResponseFrame();
            }
        });

        myInvitationsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openMyInvitationsFrame();
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logout();
            }
        });

        add(mainPanel);

        // Cargar eventos
        loadEvents();
    }

    private void loadEvents() {
        eventsPanel.removeAll();

        List<Event> events = Event.getEventsByCreator(currentUser.getUserId());

        if (events.isEmpty()) {
            JLabel noEventsLabel = new JLabel("Aún no has creado ningún evento.");
            noEventsLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            eventsPanel.add(noEventsLabel);
        } else {
            for (Event event : events) {
                JPanel eventPanel = createEventPanel(event);
                eventsPanel.add(eventPanel);
                eventsPanel.add(Box.createRigidArea(new Dimension(0, 10)));
            }
        }

        eventsPanel.revalidate();
        eventsPanel.repaint();
    }

    private JPanel createEventPanel(Event event) {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout(10, 5));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        JLabel titleLabel = new JLabel(event.getTitle());
        titleLabel.setFont(new Font("Arial", Font.BOLD, 14));

        JLabel dateLabel = new JLabel("Fecha: " + event.getEventDate() + " a las " + event.getEventTime());
        JLabel locationLabel = new JLabel("Ubicación: " + event.getLocation());

        // Añadir contador de asistentes confirmados
        int confirmedAttendees = Invitation.getConfirmedAttendeesCount(event.getEventId());
        JLabel attendeesLabel = new JLabel("Asistentes Confirmados: " + confirmedAttendees + " / " + event.getMaxParticipants());

        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new GridLayout(3, 1));
        infoPanel.add(dateLabel);
        infoPanel.add(locationLabel);
        infoPanel.add(attendeesLabel);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        JButton manageButton = new JButton("Administrar");
        manageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openEventDetailsFrame(event);
            }
        });

        buttonPanel.add(manageButton);

        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(infoPanel, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        return panel;
    }

    private void openCreateEventFrame() {
        CreateEventFrame createEventFrame = new CreateEventFrame(currentUser, this);
        createEventFrame.setVisible(true);
    }

    private void openEventDetailsFrame(Event event) {
        EventDetailsFrame eventDetailsFrame = new EventDetailsFrame(event, this);
        eventDetailsFrame.setVisible(true);
    }

    private void openInvitationResponseFrame() {
        InvitationResponseFrame invitationFrame = new InvitationResponseFrame();
        invitationFrame.setVisible(true);
    }

    private void openMyInvitationsFrame() {
        MyInvitationsFrame myInvitationsFrame = new MyInvitationsFrame(currentUser);
        myInvitationsFrame.setVisible(true);
    }

    private void logout() {
        LoginFrame loginFrame = new LoginFrame();
        loginFrame.setVisible(true);
        this.dispose();
    }

    public void refreshEvents() {
        loadEvents();
    }
}

