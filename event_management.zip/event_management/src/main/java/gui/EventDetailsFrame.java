package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Clipboard;
import java.sql.Date;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import model.Event;
import model.Invitation;
import model.User;
// AUTOR: JUAN CAMILO LLAMAS  | FECHA: 2025-3-04

public class EventDetailsFrame extends JFrame {
    private Event event;
    private DashboardFrame parentFrame;

    private JTextField emailField;
    private JButton sendInvitationButton;
    private JButton generateLinkButton;
    private JButton editEventButton;
    private JPanel invitationsPanel;

    public EventDetailsFrame(Event event, DashboardFrame parentFrame) {
        this.event = event;
        this.parentFrame = parentFrame;

        setTitle("Detalles del Evento: " + event.getTitle());
        setSize(700, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Detalles del evento
        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(new BorderLayout());

        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new GridLayout(5, 1, 5, 5));

        JLabel titleLabel = new JLabel(event.getTitle());
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));

        JLabel dateLabel = new JLabel("Fecha: " + event.getEventDate() + " a las " + event.getEventTime());
        JLabel locationLabel = new JLabel("Ubicación: " + event.getLocation());
        JLabel contactLabel = new JLabel("Contacto: " + event.getContactInfo());

        // Añadir contador de asistentes confirmados
        int confirmedAttendees = Invitation.getConfirmedAttendeesCount(event.getEventId());
        JLabel participantsLabel = new JLabel("Asistentes Confirmados: " + confirmedAttendees + " / " + event.getMaxParticipants());

        infoPanel.add(titleLabel);
        infoPanel.add(dateLabel);
        infoPanel.add(locationLabel);
        infoPanel.add(contactLabel);
        infoPanel.add(participantsLabel);

        // Botón de editar evento
        editEventButton = new JButton("Editar Evento");
        editEventButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openEditEventDialog();
            }
        });

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(editEventButton);

        detailsPanel.add(infoPanel, BorderLayout.CENTER);
        detailsPanel.add(buttonPanel, BorderLayout.SOUTH);

        if (event.getDescription() != null && !event.getDescription().isEmpty()) {
            JPanel descriptionPanel = new JPanel();
            descriptionPanel.setLayout(new BorderLayout());
            descriptionPanel.setBorder(BorderFactory.createTitledBorder("Descripción"));

            JTextArea descriptionArea = new JTextArea(event.getDescription());
            descriptionArea.setEditable(false);
            descriptionArea.setLineWrap(true);
            descriptionArea.setWrapStyleWord(true);

            JScrollPane scrollPane = new JScrollPane(descriptionArea);
            descriptionPanel.add(scrollPane, BorderLayout.CENTER);

            mainPanel.add(descriptionPanel, BorderLayout.CENTER);
        }

        mainPanel.add(detailsPanel, BorderLayout.NORTH);

        // Panel de invitaciones
        JPanel invitationsContainer = new JPanel();
        invitationsContainer.setLayout(new BorderLayout(10, 10));
        invitationsContainer.setBorder(BorderFactory.createTitledBorder("Invitaciones"));

        // Formulario de envío de invitación
        JPanel sendInvitationPanel = new JPanel();
        sendInvitationPanel.setLayout(new BorderLayout(5, 0));

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new BorderLayout(5, 0));

        JLabel emailLabel = new JLabel("Correo electrónico: ");
        emailField = new JTextField();

        inputPanel.add(emailLabel, BorderLayout.WEST);
        inputPanel.add(emailField, BorderLayout.CENTER);

        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        sendInvitationButton = new JButton("Enviar Invitación");
        generateLinkButton = new JButton("Generar Enlace de Invitación");

        buttonsPanel.add(sendInvitationButton);
        buttonsPanel.add(generateLinkButton);

        sendInvitationPanel.add(inputPanel, BorderLayout.CENTER);
        sendInvitationPanel.add(buttonsPanel, BorderLayout.EAST);

        invitationsContainer.add(sendInvitationPanel, BorderLayout.NORTH);

        // Lista de invitaciones
        invitationsPanel = new JPanel();
        invitationsPanel.setLayout(new BoxLayout(invitationsPanel, BoxLayout.Y_AXIS));

        JScrollPane invitationsScrollPane = new JScrollPane(invitationsPanel);
        invitationsScrollPane.setBorder(BorderFactory.createEmptyBorder());

        invitationsContainer.add(invitationsScrollPane, BorderLayout.CENTER);

        mainPanel.add(invitationsContainer, BorderLayout.SOUTH);

        // Agregar action listeners
        sendInvitationButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sendInvitation();
            }
        });

        generateLinkButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generateInvitationLink();
            }
        });

        add(mainPanel);

        // Cargar invitaciones
        loadInvitations();
    }

    private void loadInvitations() {
        invitationsPanel.removeAll();

        List<Invitation> invitations = Invitation.getInvitationsByEvent(event.getEventId());

        if (invitations.isEmpty()) {
            JLabel noInvitationsLabel = new JLabel("Aún no se han enviado invitaciones.");
            noInvitationsLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            invitationsPanel.add(noInvitationsLabel);
        } else {
            for (Invitation invitation : invitations) {
                JPanel invitationPanel = createInvitationPanel(invitation);
                invitationsPanel.add(invitationPanel);
                invitationsPanel.add(Box.createRigidArea(new Dimension(0, 5)));
            }
        }

        invitationsPanel.revalidate();
        invitationsPanel.repaint();
    }

    private JPanel createInvitationPanel(Invitation invitation) {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout(5, 0));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, Color.LIGHT_GRAY),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));

        JLabel emailLabel = new JLabel(invitation.getEmail());

        String statusText;
        Color statusColor;

        switch (invitation.getStatus()) {
            case ACCEPTED:
                statusText = "Aceptada";
                statusColor = new Color(0, 150, 0); // Verde
                break;
            case DECLINED:
                statusText = "Rechazada";
                statusColor = new Color(200, 0, 0); // Rojo
                break;
            default:
                statusText = "Pendiente";
                statusColor = new Color(150, 150, 0); // Amarillo
        }

        JLabel statusLabel = new JLabel(statusText);
        statusLabel.setForeground(statusColor);

        // Panel para el código de invitación y botón de copiar
        JPanel codePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        JTextField codeField = new JTextField(invitation.getInvitationCode());
        codeField.setEditable(false);
        codeField.setPreferredSize(new Dimension(200, 25));

        JButton copyButton = new JButton("Copiar Código");
        copyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StringSelection stringSelection = new StringSelection(invitation.getInvitationCode());
                Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                clipboard.setContents(stringSelection, null);
                JOptionPane.showMessageDialog(panel, "¡Código de invitación copiado al portapapeles!",
                        "Copiado", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        codePanel.add(new JLabel("Código: "));
        codePanel.add(codeField);
        codePanel.add(copyButton);

        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new GridLayout(2, 1));
        infoPanel.add(emailLabel);
        infoPanel.add(codePanel);

        JPanel actionPanel = new JPanel();
        actionPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        JButton deleteButton = new JButton("Eliminar");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteInvitation(invitation);
            }
        });

        actionPanel.add(statusLabel);
        actionPanel.add(deleteButton);

        panel.add(infoPanel, BorderLayout.WEST);
        panel.add(actionPanel, BorderLayout.EAST);

        return panel;
    }

    private void sendInvitation() {
        String email = emailField.getText().trim();

        if (email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor ingrese una dirección de correo electrónico",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            JOptionPane.showMessageDialog(this, "Formato de correo electrónico inválido",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verificar si el email pertenece a un usuario registrado
        if (!User.emailExists(email)) {
            JOptionPane.showMessageDialog(this, "Este correo electrónico no está registrado en el sistema. Solo los usuarios registrados pueden recibir invitaciones.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verificar si ya se alcanzó el máximo de asistentes confirmados
        int confirmedAttendees = Invitation.getConfirmedAttendeesCount(event.getEventId());
        if (confirmedAttendees >= event.getMaxParticipants()) {
            JOptionPane.showMessageDialog(this, "Este evento ha alcanzado su capacidad máxima de asistentes confirmados.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Invitation invitation = new Invitation(event.getEventId(), email);

        if (invitation.save()) {
            // Crear un panel con el código y un botón para copiarlo
            JPanel messagePanel = new JPanel(new BorderLayout(5, 10));

            JLabel successLabel = new JLabel("¡Invitación enviada exitosamente!");

            JPanel codePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            JTextField codeField = new JTextField(invitation.getInvitationCode());
            codeField.setEditable(false);
            codeField.setPreferredSize(new Dimension(250, 25));

            JButton copyButton = new JButton("Copiar Código");
            copyButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    StringSelection stringSelection = new StringSelection(invitation.getInvitationCode());
                    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                    clipboard.setContents(stringSelection, null);
                    JOptionPane.showMessageDialog(messagePanel, "¡Código de invitación copiado al portapapeles!",
                            "Copiado", JOptionPane.INFORMATION_MESSAGE);
                }
            });

            codePanel.add(new JLabel("Código de Invitación: "));
            codePanel.add(codeField);
            codePanel.add(copyButton);

            JLabel instructionLabel = new JLabel("Por favor comparta este código con el invitado.");

            messagePanel.add(successLabel, BorderLayout.NORTH);
            messagePanel.add(codePanel, BorderLayout.CENTER);
            messagePanel.add(instructionLabel, BorderLayout.SOUTH);

            JOptionPane.showMessageDialog(this, messagePanel, "Éxito", JOptionPane.INFORMATION_MESSAGE);

            emailField.setText("");
            loadInvitations();
        } else {
            JOptionPane.showMessageDialog(this, "Error al enviar la invitación. Por favor intente nuevamente.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void generateInvitationLink() {
        String email = emailField.getText().trim();

        if (email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor ingrese una dirección de correo electrónico",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            JOptionPane.showMessageDialog(this, "Formato de correo electrónico inválido",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verificar si el email pertenece a un usuario registrado
        if (!User.emailExists(email)) {
            JOptionPane.showMessageDialog(this, "Este correo electrónico no está registrado en el sistema. Solo los usuarios registrados pueden recibir invitaciones.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verificar si ya se alcanzó el máximo de asistentes confirmados
        int confirmedAttendees = Invitation.getConfirmedAttendeesCount(event.getEventId());
        if (confirmedAttendees >= event.getMaxParticipants()) {
            JOptionPane.showMessageDialog(this, "Este evento ha alcanzado su capacidad máxima de asistentes confirmados.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Invitation invitation = new Invitation(event.getEventId(), email);

        if (invitation.save()) {
            String invitationLink = "http://localhost:8080/respond?code=" + invitation.getInvitationCode();

            // Panel con el enlace y código de invitación
            JPanel messagePanel = new JPanel();
            messagePanel.setLayout(new BoxLayout(messagePanel, BoxLayout.Y_AXIS));

            JLabel successLabel = new JLabel("¡Enlace de invitación generado exitosamente!");
            JLabel emailInfoLabel = new JLabel("Comparta este enlace con " + email + ":");

            JPanel linkPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            JTextField linkField = new JTextField(invitationLink);
            linkField.setEditable(false);
            linkField.setPreferredSize(new Dimension(300, 25));

            JButton copyLinkButton = new JButton("Copiar Enlace");
            copyLinkButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    StringSelection stringSelection = new StringSelection(invitationLink);
                    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                    clipboard.setContents(stringSelection, null);
                    JOptionPane.showMessageDialog(messagePanel, "¡Enlace copiado al portapapeles!",
                            "Copiado", JOptionPane.INFORMATION_MESSAGE);
                }
            });

            linkPanel.add(linkField);
            linkPanel.add(copyLinkButton);

            JPanel codePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            JTextField codeField = new JTextField(invitation.getInvitationCode());
            codeField.setEditable(false);
            codeField.setPreferredSize(new Dimension(300, 25));

            JButton copyCodeButton = new JButton("Copiar Código");
            copyCodeButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    StringSelection stringSelection = new StringSelection(invitation.getInvitationCode());
                    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                    clipboard.setContents(stringSelection, null);
                    JOptionPane.showMessageDialog(messagePanel, "¡Código copiado al portapapeles!",
                            "Copiado", JOptionPane.INFORMATION_MESSAGE);
                }
            });

            codePanel.add(new JLabel("Código de Invitación: "));
            codePanel.add(codeField);
            codePanel.add(copyCodeButton);

            JLabel instructionLabel = new JLabel("Asegúrese de compartir este código con el invitado.");

            messagePanel.add(successLabel);
            messagePanel.add(Box.createRigidArea(new Dimension(0, 10)));
            messagePanel.add(emailInfoLabel);
            messagePanel.add(Box.createRigidArea(new Dimension(0, 5)));
            messagePanel.add(linkPanel);
            messagePanel.add(Box.createRigidArea(new Dimension(0, 10)));
            messagePanel.add(codePanel);
            messagePanel.add(Box.createRigidArea(new Dimension(0, 10)));
            messagePanel.add(instructionLabel);

            JOptionPane.showMessageDialog(this, messagePanel, "Enlace de Invitación", JOptionPane.INFORMATION_MESSAGE);

            emailField.setText("");
            loadInvitations();
        } else {
            JOptionPane.showMessageDialog(this, "Error al generar el enlace de invitación. Por favor intente nuevamente.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteInvitation(Invitation invitation) {
        int option = JOptionPane.showConfirmDialog(this,
                "¿Está seguro de que desea eliminar esta invitación?",
                "Confirmar Eliminación",
                JOptionPane.YES_NO_OPTION);

        if (option == JOptionPane.YES_OPTION) {
            if (invitation.delete()) {
                JOptionPane.showMessageDialog(this, "¡Invitación eliminada exitosamente!",
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
                loadInvitations();
            } else {
                JOptionPane.showMessageDialog(this, "Error al eliminar la invitación. Por favor intente nuevamente.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void openEditEventDialog() {
        JDialog editDialog = new JDialog(this, "Editar Evento", true);
        editDialog.setSize(500, 500);
        editDialog.setLocationRelativeTo(this);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Panel de formulario
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(7, 2, 10, 10));

        JLabel titleLabel = new JLabel("Título:");
        JTextField titleField = new JTextField(event.getTitle());

        JLabel locationLabel = new JLabel("Ubicación:");
        JTextField locationField = new JTextField(event.getLocation());

        JLabel dateLabel = new JLabel("Fecha (AAAA-MM-DD):");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        JTextField dateField = new JTextField(dateFormat.format(event.getEventDate()));

        JLabel timeLabel = new JLabel("Hora (HH:MM):");
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
        JTextField timeField = new JTextField(timeFormat.format(event.getEventTime()));

        JLabel contactLabel = new JLabel("Información de Contacto:");
        JTextField contactField = new JTextField(event.getContactInfo());

        JLabel maxParticipantsLabel = new JLabel("Máximo de Participantes:");
        JTextField maxParticipantsField = new JTextField(String.valueOf(event.getMaxParticipants()));

        JLabel descriptionLabel = new JLabel("Descripción:");
        JTextArea descriptionArea = new JTextArea(event.getDescription());
        descriptionArea.setLineWrap(true);
        descriptionArea.setWrapStyleWord(true);
        JScrollPane descriptionScrollPane = new JScrollPane(descriptionArea);

        formPanel.add(titleLabel);
        formPanel.add(titleField);
        formPanel.add(locationLabel);
        formPanel.add(locationField);
        formPanel.add(dateLabel);
        formPanel.add(dateField);
        formPanel.add(timeLabel);
        formPanel.add(timeField);
        formPanel.add(contactLabel);
        formPanel.add(contactField);
        formPanel.add(maxParticipantsLabel);
        formPanel.add(maxParticipantsField);
        formPanel.add(descriptionLabel);
        formPanel.add(descriptionScrollPane);

        // Panel de botones
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        JButton cancelButton = new JButton("Cancelar");
        JButton saveButton = new JButton("Guardar Cambios");

        buttonPanel.add(cancelButton);
        buttonPanel.add(saveButton);

        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Agregar action listeners
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editDialog.dispose();
            }
        });

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Validar y guardar cambios
                String title = titleField.getText().trim();
                String location = locationField.getText().trim();
                String dateStr = dateField.getText().trim();
                String timeStr = timeField.getText().trim();
                String contact = contactField.getText().trim();
                String maxParticipantsStr = maxParticipantsField.getText().trim();
                String description = descriptionArea.getText().trim();

                if (title.isEmpty() || location.isEmpty() || dateStr.isEmpty() ||
                        timeStr.isEmpty() || maxParticipantsStr.isEmpty()) {
                    JOptionPane.showMessageDialog(editDialog, "Todos los campos excepto descripción son obligatorios",
                            "Error de Validación", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Analizar fecha y hora
                Date eventDate;
                Time eventTime;
                int maxParticipants;

                try {
                    java.util.Date parsedDate = dateFormat.parse(dateStr);
                    eventDate = new Date(parsedDate.getTime());
                } catch (ParseException ex) {
                    JOptionPane.showMessageDialog(editDialog, "Formato de fecha inválido. Use AAAA-MM-DD",
                            "Error de Validación", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    java.util.Date parsedTime = timeFormat.parse(timeStr);
                    eventTime = new Time(parsedTime.getTime());
                } catch (ParseException ex) {
                    JOptionPane.showMessageDialog(editDialog, "Formato de hora inválido. Use HH:MM",
                            "Error de Validación", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    maxParticipants = Integer.parseInt(maxParticipantsStr);
                    if (maxParticipants <= 0) {
                        throw new NumberFormatException();
                    }

                    // Verificar que el nuevo máximo no sea menor que los asistentes confirmados
                    int confirmedAttendees = Invitation.getConfirmedAttendeesCount(event.getEventId());
                    if (maxParticipants < confirmedAttendees) {
                        JOptionPane.showMessageDialog(editDialog,
                                "El máximo de participantes no puede ser menor que el número actual de asistentes confirmados (" + confirmedAttendees + ")",
                                "Error de Validación", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(editDialog, "El máximo de participantes debe ser un número positivo",
                            "Error de Validación", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Actualizar el evento
                event.setTitle(title);
                event.setLocation(location);
                event.setEventDate(eventDate);
                event.setEventTime(eventTime);
                event.setContactInfo(contact);
                event.setMaxParticipants(maxParticipants);
                event.setDescription(description);

                if (event.update()) {
                    JOptionPane.showMessageDialog(editDialog, "¡Evento actualizado exitosamente!",
                            "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    editDialog.dispose();

                    // Actualizar la interfaz
                    setTitle("Detalles del Evento: " + event.getTitle());
                    refreshEventDetails();
                    parentFrame.refreshEvents();
                } else {
                    JOptionPane.showMessageDialog(editDialog, "Error al actualizar el evento. Por favor intente nuevamente.",
                            "Error de Validación", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        editDialog.add(mainPanel);
        editDialog.setVisible(true);
    }

    private void refreshEventDetails() {
        // Recrear toda la ventana con los datos actualizados
        dispose();
        EventDetailsFrame newFrame = new EventDetailsFrame(event, parentFrame);
        newFrame.setVisible(true);
    }
}

