import javax.swing.SwingUtilities;
import gui.LoginFrame;
// AUTOR: JUAN CAMILO LLAMAS  | FECHA: 2025-3-04

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
        });
    }
}

